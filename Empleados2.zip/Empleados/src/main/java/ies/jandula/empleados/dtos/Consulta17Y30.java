package ies.jandula.empleados.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Consulta17Y30 {
	
	private String nombre;
	
	private String apellidos;

}
