package ies.jandula.empleados.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Consulta52 {
	
	private String nombreCiudad;

	private String nombrePais;

	private String nombreRegion;
}
