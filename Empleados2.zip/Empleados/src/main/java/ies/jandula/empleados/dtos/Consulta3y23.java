package ies.jandula.empleados.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Consulta3y23 {
	
	private String nombreUbicacion;
	
	private String ciudad;
	
	private String nombrePais;

}
