package ies.jandula.empleados.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Consulta1Y11Y14Y20 {
	
	//Aqui da igual el nombre que le pongas
	
	private String nombreEmpleado;
	
	private String nombreDepartamento;

}
