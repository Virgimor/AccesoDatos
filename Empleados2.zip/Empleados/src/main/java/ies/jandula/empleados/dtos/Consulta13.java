package ies.jandula.empleados.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Consulta13 {
	
	private String nombrePais;

	private String nombreRegion;

}
