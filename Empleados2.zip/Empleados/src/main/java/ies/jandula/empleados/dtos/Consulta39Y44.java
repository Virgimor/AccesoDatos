package ies.jandula.empleados.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Consulta39Y44 {
	
	private String nombreGerente;

	private long empleadoPorGerente;
}
